# 对Firework Simulator v2项目进行汉化
原地址：https://codepen.io/MillerTime/pen/XgpNwb
